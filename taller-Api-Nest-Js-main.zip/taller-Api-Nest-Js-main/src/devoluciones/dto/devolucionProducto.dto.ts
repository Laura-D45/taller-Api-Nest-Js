export class DevolucionProductoDto {
    pedidoId: number;
    productoReferencia: string;
    motivo: string
    cantidad: number;
}