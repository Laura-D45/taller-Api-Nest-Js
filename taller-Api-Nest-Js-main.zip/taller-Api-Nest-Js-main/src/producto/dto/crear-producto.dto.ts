export class CrearProductoDto {
    nombre: string;
    referencia: string;
    precio: number
    talla: string;
    color: string;
    material: string;
}